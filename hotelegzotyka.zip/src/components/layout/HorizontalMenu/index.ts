import HorizontalMenu from './HorizontalMenu';
export default HorizontalMenu;