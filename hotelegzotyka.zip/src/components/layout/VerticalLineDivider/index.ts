import VerticalLineDivider from './VerticalLineDivider';
export default VerticalLineDivider;