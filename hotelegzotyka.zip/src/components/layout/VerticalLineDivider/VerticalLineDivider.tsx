import styles from "./VerticalLineDivider.module.scss";
export const VerticalLineDivider: React.VoidFunctionComponent = () => {
  return <div className={styles.divider}></div>;
};
export default VerticalLineDivider;
