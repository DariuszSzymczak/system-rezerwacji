import TwoSidesBox from './RoomsColumnList';
export default TwoSidesBox;