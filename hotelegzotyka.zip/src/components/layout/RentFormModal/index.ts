import RentFormModal from "./RentFormModal";
export default RentFormModal;
