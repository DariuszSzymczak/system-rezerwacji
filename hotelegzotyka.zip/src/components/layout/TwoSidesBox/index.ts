import TwoSidesBox from './TwoSidesBox';
export default TwoSidesBox;