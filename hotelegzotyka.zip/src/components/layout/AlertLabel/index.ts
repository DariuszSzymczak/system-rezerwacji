import AlertLabel from "./AlertLabel";
export default AlertLabel;
